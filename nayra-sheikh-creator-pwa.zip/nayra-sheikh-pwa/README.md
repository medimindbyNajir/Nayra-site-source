# Nayra Sheikh — Premium Creator Portfolio & Progressive Web App (PWA)

> **"Crafting Elegance in Motion."**  
> Official editorial website and digital sanctuary for social media creator **Nayra Sheikh** (`@nayrasheikh3552`).

An editorial creator portfolio combining the cinematic hero and floating frosted-glass aesthetics of the **Monsoon** reference with the asymmetric editorial composition, vertical typography, and collection panels of the **Gallery Storefront** reference.

---

## 🌟 Creator Analysis & Design System

- **Creator**: Nayra Sheikh
- **Profiles**:
  - **Instagram**: [instagram.com/nayrasheikh3552](https://www.instagram.com/nayrasheikh3552/)
  - **YouTube**: [youtube.com/@Nayrasheikh3552](https://m.youtube.com/@Nayrasheikh3552)
- **Niche & Pillars**:
  1. **Ethnic Couture & Silhouettes**: Embroidered velvet gowns, flowing shararas, traditional South Asian couture with modern poise.
  2. **Soulful Words & Dialogues**: Poetic Hindi & Urdu voiceovers, emotional dialogues (*"Mai logon se badla nahi liya karti..."*), kindness and reflection.
  3. **Faith & Personal Resilience**: Grounded spiritual era (*"Himmat Hari to Sab Haar Jaungi"*), patience and gratitude.
  4. **Daily Aesthetics & Vlogs**: Rooftop walks, Pista House chai breaks, and serene everyday vignettes.
- **Color Palette**:
  - `Obsidian Noir` (`#0b0b0e`): Primary background and cinematic depth.
  - `Emerald Malachite` (`#143d34`): Traditional South Asian regal contrast.
  - `Antique Gold` (`#d4af37` / `#e5c07b`): Zari embroidery and typography highlights.
  - `Warm Alabaster` (`#f7f4ee`): Surface card tint and high-contrast text.
  - `Deep Crimson` (`#8c2d3e`): Sharara and rose floral accents.
- **Typography**:
  - Display / Editorial: `Cormorant Garamond` & `Playfair Display`
  - Body & UI: `Plus Jakarta Sans` & `Inter`

---

## 📱 Progressive Web App (PWA) Native Features

This portfolio is built to function as an installable native application:
- **Web App Manifest (`manifest.webmanifest`)**: Configured for `standalone` display, portrait lock, custom theme color (`#0b0b0e`), and home screen shortcuts (Instagram, YouTube, Collaborate).
- **Service Worker (`sw.js`)**: Intelligent caching (Stale-While-Revalidate for app shell, cache fallback for offline browsing).
- **Offline Experience (`offline.html`)**: Graceful offline fallback screen when connection drops.
- **In-App PWA Install Banner (`PwaInstallBanner.tsx`)**: Prompts visitors on Android/iOS/Desktop to add the portfolio directly to their device home screen.
- **High-Resolution Icons**: 192x192, 512x512, and maskable icons.

---

## 📂 Project Architecture

```text
nayra-sheikh-pwa/
├── dist/                          # Ready-to-deploy production build (Zero-dependency)
│   ├── index.html                 # Standalone production web application
│   ├── manifest.webmanifest       # PWA Web App Manifest
│   ├── sw.js                      # Service Worker caching & offline engine
│   ├── favicon.svg                # Monogram vector favicon
│   ├── offline.html               # Offline fallback template
│   └── icons/
│       ├── icon-192.png           # 192x192 PWA Icon
│       ├── icon-512.png           # 512x512 PWA Icon
│       └── icon-maskable.png      # Maskable PWA Icon
├── src/
│   ├── components/
│   │   ├── Navbar.tsx             # Centered floating frosted-glass pill navbar
│   │   ├── Hero.tsx               # Top-anchored cinematic hero with editorial marquee
│   │   ├── Introduction.tsx       # Editorial split layout & grounded biography
│   │   ├── SocialStats.tsx        # Magazine-style metrics cards
│   │   ├── FeaturedContent.tsx    # Asymmetric gallery with real video previews
│   │   ├── InstagramGallery.tsx   # Filterable masonry visual diary
│   │   ├── YouTubeSection.tsx     # Dark cinema lounge with embedded playback
│   │   ├── AboutSection.tsx       # "Behind the content" storytelling
│   │   ├── ContentCategories.tsx  # Gallery Storefront vertical rotated panels
│   │   ├── CollaborationSection.tsx # Brand partnership services & deliverables
│   │   ├── SocialCTA.tsx          # Full-width closing visual CTA
│   │   ├── Footer.tsx             # Editorial footer with navigation & back-to-top
│   │   ├── VideoModal.tsx         # Inline responsive YouTube player
│   │   ├── ContactModal.tsx       # Brand inquiry form with toast feedback
│   │   └── PwaInstallBanner.tsx   # Native app installation banner
│   ├── data/
│   │   └── creator.ts             # Centralized source of truth for all content & links
│   ├── App.tsx                    # Master layout & modal state management
│   ├── main.tsx                   # React root mount & PWA service worker registration
│   └── index.css                  # Tailwind CSS v4 setup & custom utilities
├── public/
│   ├── manifest.webmanifest
│   ├── sw.js
│   ├── favicon.svg
│   ├── offline.html
│   └── icons/
├── package.json                   # React 19, Tailwind CSS v4, Framer Motion, Vite
├── vite.config.ts                 # Vite bundler configuration
├── tsconfig.json                  # TypeScript strict configuration
└── README.md                      # Documentation & deployment guide
```

---

## 🚀 How to Deploy

### Option 1: Direct Cloudflare Pages / Netlify / Vercel (Instant)
Deploy the `dist/` folder directly:
- **Cloudflare Pages**: Go to Workers & Pages > Create application > Pages > Upload the `dist/` folder.
- **Netlify**: Drag and drop the `dist/` folder into Netlify Drop.
- **Vercel**: Deploy via Vercel CLI (`vercel dist --prod`) or connect GitHub repository.

### Option 2: Run Locally
```bash
# 1. Install dependencies
npm install

# 2. Start development server
npm run dev

# 3. Build for production
npm run build
```

---

## 💎 Verified Content Citations
All content, video IDs, titles, and quotes are directly grounded in Nayra Sheikh's public profiles:
- *I am in my Era ... Himmat Hari to sab har jaungi* (`OclR3AtLDug`)
- *Heavy gown dresses is so amazing..* (`mvCy6-2D5Lo`)
- *Mai logon se badla nahi liya karti because...* (`0BrUGfjItcY`)
- *#my fav dresses #sararasuit #fashionable new trending outfit* (`hmKiXcDlBEo`)
- *This song chai ki tapri ... Pista House* (`G_2gHjsmyes`)
- *Tere waste Mera isque sufiaana* (`0BbVte1tjnY`)
