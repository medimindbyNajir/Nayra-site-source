export interface CreatorProfile {
  name: string;
  handle: string;
  avatar: string;
  heroBackground: string;
  eyebrow: string;
  headline: string;
  supportingStatement: string;
  bioShort: string;
  bioFull: string[];
  quote: string;
  socials: {
    instagram: string;
    youtube: string;
  };
  metrics: {
    label: string;
    value: string;
    description: string;
  }[];
  palette: {
    name: string;
    hex: string;
    role: string;
  }[];
}

export interface FeaturedItem {
  id: string;
  title: string;
  category: string;
  platform: 'Instagram' | 'YouTube';
  badge: string;
  views?: string;
  likes?: string;
  quote?: string;
  aspect: 'tall' | 'wide' | 'standard';
  youtubeId?: string;
  url: string;
  image: string;
  description: string;
}

export interface VideoItem {
  id: string;
  youtubeId: string;
  title: string;
  category: string;
  views: string;
  likes: string;
  date: string;
  duration: string;
  quote: string;
  thumbnail: string;
  url: string;
}

export interface GalleryItem {
  id: string;
  title: string;
  category: 'Couture' | 'Soulful' | 'Aesthetics' | 'Resilience';
  caption: string;
  date: string;
  image: string;
  url: string;
  likes?: string;
  tags: string[];
}

export interface ContentCategory {
  id: string;
  title: string;
  tagline: string;
  description: string;
  image: string;
  countLabel: string;
  accent: string;
}

export interface CollaborationService {
  title: string;
  tag: string;
  description: string;
  deliverables: string[];
}

export const CREATOR_DATA: CreatorProfile = {
  name: "Nayra Sheikh",
  handle: "@nayrasheikh3552",
  avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=800&q=80",
  heroBackground: "https://images.unsplash.com/photo-1518895949257-7621c3c786d7?auto=format&fit=crop&w=2000&q=85",
  eyebrow: "ETHNIC COUTURE & VISUAL STORYTELLER",
  headline: "Crafting Elegance in Motion.",
  supportingStatement: "Embracing timeless South Asian couture, heartfelt poetry, and the quiet resilience of everyday moments.",
  bioShort: "Nayra Sheikh creates short-form visual poetry centered around exquisite traditional couture, heartfelt Bollywood melodies, emotional dialogues, and reflective faith.",
  bioFull: [
    "Rooted in grace and cultural heritage, Nayra Sheikh has established a distinctive aesthetic across Instagram and YouTube. Her content weaves together the intricate craftsmanship of Indian ethnic wear—from heavy embroidered velvet gowns and flowing sharara suits to pastel drapes—with soulful reflections that touch upon patience, kindness, and personal resilience.",
    "Rather than following fast, fleeting internet noise, Nayra's creative signature is intimate and deliberate. Whether capturing a quiet rooftop stroll at dusk, sharing a comforting cup of Irani chai from Pista House, or voicing poetic reminders about having a heart that refuses to hurt others, her presence is calm, dignified, and visually opulent.",
    "Today, she engages a dedicated and growing audience who celebrate authentic elegance, meaningful short-form cinema, and timeless South Asian style."
  ],
  quote: "“Himmat hari toh sab haar jaungi — in every season of life, faith and patience lead the way.”",
  socials: {
    instagram: "https://www.instagram.com/nayrasheikh3552/",
    youtube: "https://m.youtube.com/@Nayrasheikh3552"
  },
  metrics: [
    {
      label: "Viral Reflection",
      value: "1.3K+",
      description: "Organic views on personal resilience era short"
    },
    {
      label: "Couture Showcase",
      value: "1.0K+",
      description: "Views on embroidered velvet & gown feature"
    },
    {
      label: "Visual Format",
      value: "Short-Form",
      description: "Curated cinematic Reels & YouTube Shorts"
    },
    {
      label: "Creative Pillars",
      value: "3 Niche Areas",
      description: "Ethnic Couture, Soulful Words & Everyday Life"
    }
  ],
  palette: [
    { name: "Obsidian Noir", hex: "#0b0b0e", role: "Primary Background" },
    { name: "Emerald Malachite", hex: "#143d34", role: "Editorial Contrast" },
    { name: "Antique Gold", hex: "#d4af37", role: "Accent & Highlights" },
    { name: "Warm Alabaster", hex: "#f7f4ee", role: "Surface & Card Tint" },
    { name: "Deep Crimson", hex: "#8c2d3e", role: "Embroidery Accent" },
    { name: "Muted Slate", hex: "#8e8e93", role: "Supporting Copy" }
  ]
};

export const FEATURED_CONTENT: FeaturedItem[] = [
  {
    id: "feat-1",
    title: "I Am In My Era — Himmat Hari Toh Sab Haar Jaungi",
    category: "Spiritual & Resilience",
    platform: "YouTube",
    badge: "Most Viewed Era Reflection",
    views: "1,342 views",
    likes: "155 likes",
    quote: "Meri doobti kashti ko Maula tu sahara de... Himmat hari to sab haar jaungi.",
    aspect: "tall",
    youtubeId: "OclR3AtLDug",
    url: "https://m.youtube.com/watch?v=OclR3AtLDug",
    image: "https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=1000&q=80",
    description: "An intimate, soulful reflection on holding onto faith, reading prayers, and finding calm courage in the midst of trials."
  },
  {
    id: "feat-2",
    title: "The Regal Velvet & Emerald Gown Showcase",
    category: "Ethnic Couture",
    platform: "YouTube",
    badge: "Signature Fashion Look",
    views: "1,026 views",
    likes: "14 likes",
    quote: "Intricate gold zari embroidery with flowing turquoise dupatta.",
    aspect: "wide",
    youtubeId: "mvCy6-2D5Lo",
    url: "https://m.youtube.com/watch?v=mvCy6-2D5Lo",
    image: "https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=1200&q=80",
    description: "Celebrating traditional South Asian craftsmanship in a dramatic multi-layered velvet gown adorned with intricate motifs."
  },
  {
    id: "feat-3",
    title: "Mai Logon Se Badla Nahi Liya Karti...",
    category: "Soulful Poetry",
    platform: "YouTube",
    badge: "Poetic Short",
    views: "914 views",
    likes: "21 likes",
    quote: "Mere paas aisa dil hai jo kisi ko takleef dene se inkaar karta hai.",
    aspect: "standard",
    youtubeId: "0BrUGfjItcY",
    url: "https://m.youtube.com/watch?v=0BrUGfjItcY",
    image: "https://images.unsplash.com/photo-1490750967868-88aa4486c946?auto=format&fit=crop&w=800&q=80",
    description: "A tender, heartfelt message amidst garden blossoms, honoring kindness and gentle forgiveness over bitterness."
  },
  {
    id: "feat-4",
    title: "Black Sharara Suit & Rooftop Solitude",
    category: "Fashion & Elegance",
    platform: "YouTube",
    badge: "Trending Style",
    views: "336 views",
    likes: "13 likes",
    quote: "Suno to zara yeh phoolon ki vaadi... Veer-Zaara memories.",
    aspect: "standard",
    youtubeId: "hmKiXcDlBEo",
    url: "https://m.youtube.com/watch?v=hmKiXcDlBEo",
    image: "https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?auto=format&fit=crop&w=800&q=80",
    description: "Crimson and gold embroidered black sharara, moving with timeless grace against an open monsoon sky."
  },
  {
    id: "feat-5",
    title: "Tere Waste Mera Ishq Sufiyana",
    category: "Aesthetic Audio",
    platform: "YouTube",
    badge: "Romantic Lyric",
    views: "291 views",
    likes: "21 likes",
    quote: "A framed aesthetic heart over lush greenery and nostalgic melody.",
    aspect: "standard",
    youtubeId: "0BbVte1tjnY",
    url: "https://m.youtube.com/watch?v=0BbVte1tjnY",
    image: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=800&q=80",
    description: "Blending classic Sufi romantic melody with minimal, warm outdoor visual compositions."
  },
  {
    id: "feat-6",
    title: "Chai Ki Tapri & Gentle Recovery",
    category: "Daily Moments",
    platform: "YouTube",
    badge: "Lifestyle Vlog",
    views: "325 views",
    likes: "6 likes",
    quote: "Pista House chai, rhythm of the day, healing through life's little pauses.",
    aspect: "standard",
    youtubeId: "G_2gHjsmyes",
    url: "https://m.youtube.com/watch?v=G_2gHjsmyes",
    image: "https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&w=800&q=80",
    description: "Candid lifestyle snippet capturing the warmth of hot chai and gentle resilience during recovery."
  }
];

export const YOUTUBE_VIDEOS: VideoItem[] = [
  {
    id: "yt-1",
    youtubeId: "OclR3AtLDug",
    title: "I am in my Era ... Himmat Hari to sab har jaungi .😭😢",
    category: "Spiritual & Resilience",
    views: "1.3K+ views",
    likes: "155 likes",
    date: "Sep 2025",
    duration: "0:11",
    quote: "Meri doobti kashti ko Maula tu sahara de... Himmat hari to sab haar jaungi ❤️",
    thumbnail: "https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=800&q=80",
    url: "https://m.youtube.com/watch?v=OclR3AtLDug"
  },
  {
    id: "yt-2",
    youtubeId: "mvCy6-2D5Lo",
    title: "Heavy gown dresses is so amazing.. #thumbnail #youtubeshorts",
    category: "Ethnic Couture",
    views: "1.0K+ views",
    likes: "14 likes",
    date: "Sep 2025",
    duration: "0:14",
    quote: "Ha kya batau tujhe kitna pyar kiya, har ghadi bas tera intezar kiya...",
    thumbnail: "https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=800&q=80",
    url: "https://m.youtube.com/watch?v=mvCy6-2D5Lo"
  },
  {
    id: "yt-3",
    youtubeId: "0BrUGfjItcY",
    title: "Mai logon se badla nahi liya karti because... #emotional #feeling",
    category: "Soulful Poetry",
    views: "914 views",
    likes: "21 likes",
    date: "Sep 2025",
    duration: "0:07",
    quote: "Mere pass Aisa Dil Hai jo kisi ko takleef dene se Inkaar karta hai..!!",
    thumbnail: "https://images.unsplash.com/photo-1490750967868-88aa4486c946?auto=format&fit=crop&w=800&q=80",
    url: "https://m.youtube.com/watch?v=0BrUGfjItcY"
  },
  {
    id: "yt-4",
    youtubeId: "hmKiXcDlBEo",
    title: "#my fav dresses #sararasuit #fashionable new trending outfit",
    category: "Fashion & Sharara",
    views: "336 views",
    likes: "13 likes",
    date: "Jun 2025",
    duration: "0:19",
    quote: "Suno to zara yeh phoolon ki vaadi hamare hi koi kahani hai sunati...",
    thumbnail: "https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?auto=format&fit=crop&w=800&q=80",
    url: "https://m.youtube.com/watch?v=hmKiXcDlBEo"
  },
  {
    id: "yt-5",
    youtubeId: "G_2gHjsmyes",
    title: "This song 🎵 👌 chai ki tapri ......#feelthemusic #PistaHouse",
    category: "Lifestyle Moments",
    views: "325 views",
    likes: "6 likes",
    date: "Aug 2026",
    duration: "0:20",
    quote: "Pista House chai and biscuits with hospital recovery reflection.",
    thumbnail: "https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&w=800&q=80",
    url: "https://m.youtube.com/watch?v=G_2gHjsmyes"
  },
  {
    id: "yt-6",
    youtubeId: "0BbVte1tjnY",
    title: "Tere waste Mera isque sufiaana Mera isque sufiaana♥️",
    category: "Aesthetic Melodies",
    views: "291 views",
    likes: "21 likes",
    date: "Oct 2023",
    duration: "0:10",
    quote: "Tere waste mera ishq sufiyana... aesthetic Polaroid cutout over lush green leaves.",
    thumbnail: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=800&q=80",
    url: "https://m.youtube.com/watch?v=0BbVte1tjnY"
  }
];

export const INSTAGRAM_POSTS: GalleryItem[] = [
  {
    id: "ig-1",
    title: "Regal Velvet & Embroidered Gown",
    category: "Couture",
    caption: "Heavy gown dresses are sheer art. Intricate zari gold borders set against rich velvet and sheer emerald drapery.",
    date: "Autumn 2025",
    image: "https://images.unsplash.com/photo-1566174053879-31528523f8ae?auto=format&fit=crop&w=900&q=80",
    url: "https://www.instagram.com/nayrasheikh3552/",
    likes: "Curated Look",
    tags: ["#ethnicwear", "#velvetgown", "#southasianfashion", "#nayrasheikh"]
  },
  {
    id: "ig-2",
    title: "Garden Reverie: Royal Blue & Red Florals",
    category: "Soulful",
    caption: "Mai logon se badla nahi liya karti... Mere paas aisa dil hai jo kisi ko takleef dene se inkaar karta hai. ❤️",
    date: "September 2025",
    image: "https://images.unsplash.com/photo-1496747611176-843222e1e57c?auto=format&fit=crop&w=900&q=80",
    url: "https://www.instagram.com/nayrasheikh3552/",
    likes: "Poetry Reel",
    tags: ["#soulfulpoetry", "#kindness", "#aestheticreel", "#nayrasheikh3552"]
  },
  {
    id: "ig-3",
    title: "Rooftop Stroll in Intricate Black Sharara",
    category: "Couture",
    caption: "Suno to zara yeh phoolon ki vaadi... Black and crimson sharara silhouette taking flight under monsoon breeze.",
    date: "Summer 2025",
    image: "https://images.unsplash.com/photo-1539109136881-3be0616acf4b?auto=format&fit=crop&w=900&q=80",
    url: "https://www.instagram.com/nayrasheikh3552/",
    likes: "Trending Style",
    tags: ["#shararasuit", "#blacksuit", "#veerzaara", "#traditionalattire"]
  },
  {
    id: "ig-4",
    title: "Spiritual Grounding & Faith in My Era",
    category: "Resilience",
    caption: "Himmat hari to sab haar jaungi. Seeking guidance, peace, and steadfast patience through life's turning chapters.",
    date: "September 2025",
    image: "https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=900&q=80",
    url: "https://www.instagram.com/nayrasheikh3552/",
    likes: "Era Reflection",
    tags: ["#trustonallah", "#feeling", "#spiritualcalm", "#patience"]
  },
  {
    id: "ig-5",
    title: "Pista House Chai & The Slow Hours",
    category: "Aesthetics",
    caption: "Chai ki tapri... Taking slow sips, enjoying fragrant Irani chai, and remembering that healing takes its own sweet time.",
    date: "August 2026",
    image: "https://images.unsplash.com/photo-1544787219-7f47ccb76574?auto=format&fit=crop&w=900&q=80",
    url: "https://www.instagram.com/nayrasheikh3552/",
    likes: "Candid Vignette",
    tags: ["#chaikitapri", "#pistahouse", "#aestheticmoments", "#lifestylevlog"]
  },
  {
    id: "ig-6",
    title: "Sufi Beats & Vintage Framing",
    category: "Soulful",
    caption: "Tere waste mera ishq sufiyana... Hand heart silhouette touching the sky over misty foliage.",
    date: "October 2023",
    image: "https://images.unsplash.com/photo-1516589178581-6cd7833ae3b2?auto=format&fit=crop&w=900&q=80",
    url: "https://www.instagram.com/nayrasheikh3552/",
    likes: "Retro Melody",
    tags: ["#ishqsufiana", "#bollywoodaesthetic", "#lyricalshorts"]
  }
];

export const CONTENT_CATEGORIES: ContentCategory[] = [
  {
    id: "cat-couture",
    title: "Ethnic Couture & Silhouettes",
    tagline: "Heavy gowns, shararas, and regal embroidery",
    description: "Detailed looks showcasing South Asian craftsmanship, rich velvet textures, gold zari handiwork, and timeless drape movements.",
    image: "https://images.unsplash.com/photo-1566174053879-31528523f8ae?auto=format&fit=crop&w=1000&q=80",
    countLabel: "Curated Looks",
    accent: "#d4af37"
  },
  {
    id: "cat-poetry",
    title: "Soulful Words & Dialogues",
    tagline: "Heartfelt Hindi & Urdu reflections",
    description: "Spoken poetry and lyrical soundbites capturing kindness, emotional depth, and holding peace in a loud world.",
    image: "https://images.unsplash.com/photo-1490750967868-88aa4486c946?auto=format&fit=crop&w=1000&q=80",
    countLabel: "Poetic Reels",
    accent: "#8c2d3e"
  },
  {
    id: "cat-resilience",
    title: "Faith, Era & Inner Strength",
    tagline: "Himmat Hari Toh Sab Haar Jaungi",
    description: "Quiet prayer moments, spiritual reflections, and grounded reminders about endurance, hope, and personal transformation.",
    image: "https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=1000&q=80",
    countLabel: "Spiritual Shorts",
    accent: "#143d34"
  },
  {
    id: "cat-lifestyle",
    title: "Daily Aesthetics & Vlogs",
    tagline: "Chai breaks, terrace breezes, candid life",
    description: "Everyday life snippets—from Pista House chai pauses to serene garden walks—celebrating calm simplicity.",
    image: "https://images.unsplash.com/photo-1544787219-7f47ccb76574?auto=format&fit=crop&w=1000&q=80",
    countLabel: "Visual Stories",
    accent: "#e5c07b"
  }
];

export const COLLABORATION_SERVICES: CollaborationService[] = [
  {
    title: "Ethnic Couture & Fashion Styling",
    tag: "Fashion Feature",
    description: "High-end visual showcase of traditional lehengas, sharara suits, designer gowns, and ethnic pret with slow-motion editorial framing.",
    deliverables: ["Dedicated 4K Short / Reel", "High-Resolution Editorial Stills", "Soundtrack & Mood Alignment", "Direct Product Tagging"]
  },
  {
    title: "Lyrical & Dialogue Brand Integrations",
    tag: "Short-Form Production",
    description: "Authentic narrative integrations pairing products with soulful voiceovers, emotional dialogues, and organic lifestyle placement.",
    deliverables: ["Custom Script / Dialogue Concept", "Full Production & Editing", "Multi-Platform Distribution (IG & YT)", "Audience Engagement Tracking"]
  },
  {
    title: "Aesthetic UGC & Lifestyle Content",
    tag: "Creative Content",
    description: "Natural, non-intrusive product features for jewellery, fragrance, ethnic footwear, tea/lifestyle brands, and wellness aesthetics.",
    deliverables: ["Organic Story Mentions", "B-roll & Detail Macro Shots", "Whitelisting & Ad Rights Available", "High-CTR Hook Concept"]
  },
  {
    title: "Brand Ambassador & Event Appearance",
    tag: "Strategic Alliance",
    description: "Long-term seasonal brand representation, festive campaigns (Eid, Diwali, Weddings), and runway/boutique store launches.",
    deliverables: ["Multi-Reel Campaign Series", "Cross-Platform Co-authoring", "Exclusive Collection Previews", "Bespoke Creator Collaboration"]
  }
];
