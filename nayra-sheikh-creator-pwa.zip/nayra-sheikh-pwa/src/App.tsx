import React, { useState } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Introduction from './components/Introduction';
import SocialStats from './components/SocialStats';
import FeaturedContent from './components/FeaturedContent';
import InstagramGallery from './components/InstagramGallery';
import YouTubeSection from './components/YouTubeSection';
import AboutSection from './components/AboutSection';
import ContentCategories from './components/ContentCategories';
import CollaborationSection from './components/CollaborationSection';
import SocialCTA from './components/SocialCTA';
import Footer from './components/Footer';
import VideoModal from './components/VideoModal';
import ContactModal from './components/ContactModal';
import PwaInstallBanner from './components/PwaInstallBanner';

export default function App() {
  const [activeVideoId, setActiveVideoId] = useState<string | null>(null);
  const [contactModalOpen, setContactModalOpen] = useState(false);

  const handlePlayVideo = (youtubeId: string) => {
    setActiveVideoId(youtubeId);
  };

  const handleCloseVideo = () => {
    setActiveVideoId(null);
  };

  return (
    <div className="w-full min-h-screen bg-[#0b0b0e] text-[#f5f5f7] relative selection:bg-[#d4af37]/30 selection:text-[#f7e4be]">
      {/* 1. Floating Monsoon-style Frosted Glass Pill Navbar */}
      <Navbar onOpenContact={() => setContactModalOpen(true)} />

      {/* 2. Hero — Cinematic Creator Intro */}
      <Hero onPlayFeaturedVideo={handlePlayVideo} />

      {/* 3. Creator Introduction — Editorial Split Layout */}
      <Introduction />

      {/* 4. Social Statistics — Magazine Style Metrics */}
      <SocialStats />

      {/* 5. Featured Content — Asymmetric Gallery */}
      <FeaturedContent onPlayVideo={handlePlayVideo} />

      {/* 6. Instagram Visual Gallery — Curated Reels & Looks */}
      <InstagramGallery />

      {/* 7. YouTube Cinema Section — Watch Nayra */}
      <YouTubeSection onPlayVideo={handlePlayVideo} />

      {/* 8. Creator Story / About — Behind the Content */}
      <AboutSection />

      {/* 9. Content Categories — Gallery Storefront Vertical Panels */}
      <ContentCategories />

      {/* 10. Collaboration / Brand Section */}
      <CollaborationSection onOpenContact={() => setContactModalOpen(true)} />

      {/* 11. Social CTA — Follow The Journey */}
      <SocialCTA />

      {/* 12. Minimal Editorial Footer */}
      <Footer />

      {/* Interactive In-App Video Player Modal */}
      <VideoModal
        youtubeId={activeVideoId}
        onClose={handleCloseVideo}
      />

      {/* Interactive Collaboration Inquiry Modal */}
      <ContactModal
        isOpen={contactModalOpen}
        onClose={() => setContactModalOpen(false)}
      />

      {/* PWA Native Install Prompt Banner */}
      <PwaInstallBanner />
    </div>
  );
}
