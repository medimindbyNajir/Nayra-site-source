import React from 'react';
import { motion } from 'framer-motion';
import { Youtube, Play, ArrowUpRight, Clock, Eye, ThumbsUp, Sparkles } from 'lucide-react';
import { YOUTUBE_VIDEOS, CREATOR_DATA } from '../data/creator';

interface YouTubeSectionProps {
  onPlayVideo: (youtubeId: string) => void;
}

export default function YouTubeSection({ onPlayVideo }: YouTubeSectionProps) {
  return (
    <section id="youtube" className="py-20 sm:py-32 bg-[#09090c] relative overflow-hidden text-white">
      {/* Subtle theater backdrop glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-full max-w-4xl h-96 bg-red-950/20 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 sm:mb-16 gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-500/10 border border-red-500/20 text-xs font-semibold tracking-[0.2em] text-red-400 uppercase font-sans-clean mb-3">
              <Youtube className="w-3.5 h-3.5 fill-current" />
              <span>THE CINEMA LOUNGE</span>
            </div>
            <h2 className="font-editorial text-4xl sm:text-5xl lg:text-6xl font-normal text-white">
              Watch <span className="italic text-[#e5c07b]">Nayra.</span>
            </h2>
            <p className="mt-3 text-sm text-white/60 font-sans-clean max-w-lg">
              Cinematic short-form storytelling, resonant Bollywood soundtracks, and poignant era reflections produced for the moving screen.
            </p>
          </div>

          <a
            href={CREATOR_DATA.socials.youtube}
            target="_blank"
            rel="noopener noreferrer"
            className="cursor-pointer inline-flex items-center gap-2 px-6 py-3 rounded-full bg-red-600 hover:bg-red-700 text-white font-semibold text-xs uppercase tracking-wider shadow-lg shadow-red-600/25 hover:scale-[1.02] active:scale-[0.98] transition-all self-start md:self-auto"
          >
            <Youtube className="w-4 h-4 fill-current" />
            <span>Visit YouTube Channel</span>
            <ArrowUpRight className="w-4 h-4" />
          </a>
        </div>

        {/* Cinematic Video Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {YOUTUBE_VIDEOS.map((video, idx) => (
            <motion.div
              key={video.id}
              initial={{ opacity: 0, y: 25 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: idx * 0.1 }}
              className="group relative rounded-3xl overflow-hidden bg-[#13131a] border border-white/10 hover:border-red-500/40 shadow-2xl transition-all duration-300 flex flex-col justify-between cursor-pointer"
              onClick={() => onPlayVideo(video.youtubeId)}
            >
              {/* Thumbnail Container */}
              <div className="relative aspect-[16/10] overflow-hidden bg-black">
                <img
                  src={video.thumbnail}
                  alt={video.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 opacity-90 group-hover:opacity-100"
                />
                
                {/* Play Button Overlay */}
                <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-colors flex items-center justify-center">
                  <div className="w-14 h-14 rounded-full bg-red-600/90 border border-white/30 flex items-center justify-center text-white shadow-xl shadow-red-600/40 group-hover:scale-110 group-hover:bg-red-500 transition-all duration-300">
                    <Play className="w-6 h-6 fill-current ml-1" />
                  </div>
                </div>

                {/* Duration Badge */}
                <div className="absolute bottom-3 right-3 px-2 py-0.5 rounded bg-black/80 text-[11px] font-mono text-white/90 flex items-center gap-1 backdrop-blur-sm">
                  <Clock className="w-3 h-3 text-red-400" />
                  <span>{video.duration}</span>
                </div>

                {/* Category Badge */}
                <div className="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-black/60 border border-white/15 text-[10px] uppercase tracking-wider font-semibold text-[#f7e4be] backdrop-blur-md">
                  {video.category}
                </div>
              </div>

              {/* Video Info Details */}
              <div className="p-6 flex flex-col justify-between flex-1">
                <div>
                  <div className="flex items-center gap-3 text-xs text-white/50 font-sans-clean mb-2">
                    <span className="flex items-center gap-1">
                      <Eye className="w-3.5 h-3.5 text-red-400" />
                      <span>{video.views}</span>
                    </span>
                    <span>•</span>
                    <span className="flex items-center gap-1">
                      <ThumbsUp className="w-3.5 h-3.5 text-red-400" />
                      <span>{video.likes}</span>
                    </span>
                    <span>•</span>
                    <span>{video.date}</span>
                  </div>

                  <h3 className="font-editorial text-xl sm:text-2xl text-white font-normal leading-snug group-hover:text-[#e5c07b] transition-colors">
                    {video.title}
                  </h3>

                  {video.quote && (
                    <p className="mt-2 text-xs text-white/70 italic font-editorial line-clamp-2">
                      "{video.quote}"
                    </p>
                  )}
                </div>

                <div className="mt-5 pt-3 border-t border-white/10 flex items-center justify-between text-xs">
                  <span className="text-white/40 font-mono">@Nayrasheikh3552</span>
                  <span className="text-red-400 font-medium inline-flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                    <span>Watch In-App</span>
                    <Play className="w-3 h-3 fill-current" />
                  </span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Channel Banner Callout */}
        <div className="mt-14 p-8 rounded-3xl bg-gradient-to-r from-[#14141d] via-[#1b151f] to-[#14141d] border border-white/10 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-red-600 flex items-center justify-center text-white shadow-xl shadow-red-600/30">
              <Youtube className="w-8 h-8 fill-current" />
            </div>
            <div>
              <p className="font-editorial text-2xl text-white font-normal">
                Subscribe for New Short-Form Drops
              </p>
              <p className="text-xs sm:text-sm text-white/60 font-sans-clean">
                Never miss an ethnic lookbook, soulful reel dialogue, or behind-the-scenes moment.
              </p>
            </div>
          </div>

          <a
            href={CREATOR_DATA.socials.youtube}
            target="_blank"
            rel="noopener noreferrer"
            className="cursor-pointer inline-flex items-center gap-2 px-7 py-3.5 rounded-full bg-white text-black font-semibold text-xs sm:text-sm uppercase tracking-wider hover:bg-[#e5c07b] transition-colors whitespace-nowrap shadow-lg"
          >
            <span>Subscribe on YouTube</span>
            <ArrowUpRight className="w-4 h-4" />
          </a>
        </div>

      </div>
    </section>
  );
}
