import React from 'react';
import { motion } from 'framer-motion';
import { Sparkles, Instagram, Play, ArrowDown, ChevronRight } from 'lucide-react';
import { CREATOR_DATA } from '../data/creator';

interface HeroProps {
  onPlayFeaturedVideo: (youtubeId: string) => void;
}

export default function Hero({ onPlayFeaturedVideo }: HeroProps) {
  const editorialTags = [
    "Ethnic Couture",
    "Embroidered Velvet",
    "Sharara Silhouettes",
    "Soulful Poetry",
    "Faith & Resilience",
    "Aesthetic Vlogs"
  ];

  return (
    <section id="hero" className="relative w-full min-h-[95vh] sm:min-h-screen flex flex-col justify-between overflow-hidden bg-[#0b0b0e]">
      {/* Background Visual Layer with cinematic atmosphere */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1518895949257-7621c3c786d7?auto=format&fit=crop&w=2200&q=85"
          alt="Nayra Sheikh Editorial Backdrop"
          className="w-full h-full object-cover object-center scale-105 animate-pulse duration-[12000ms] opacity-45"
        />

        {/* Layered cinematic gradients */}
        <div className="absolute inset-0 bg-gradient-to-b from-[#0b0b0e]/80 via-transparent to-[#0b0b0e]" />
        <div className="absolute inset-0 bg-radial-[ellipse_at_top] from-[#143d34]/40 via-transparent to-[#0b0b0e]/90" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0b0b0e]/85 via-transparent to-[#0b0b0e]/85" />
      </div>

      {/* Main Top-Anchored Hero Content */}
      <div className="relative z-10 w-full max-w-4xl mx-auto px-4 sm:px-6 pt-32 sm:pt-40 pb-16 flex flex-col items-center text-center">
        {/* Eyebrow Pill */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.15, ease: "easeOut" }}
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/10 border border-[#d4af37]/40 backdrop-blur-md mb-6 shadow-sm shadow-[#d4af37]/20"
        >
          <Sparkles className="w-3.5 h-3.5 text-[#e5c07b]" />
          <span className="text-[11px] sm:text-xs font-semibold tracking-[0.22em] uppercase text-[#f7e4be]">
            {CREATOR_DATA.eyebrow}
          </span>
        </motion.div>

        {/* Editorial Display Headline */}
        <motion.h1
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.85, delay: 0.3, ease: [0.16, 1, 0.3, 1] }}
          className="font-editorial text-4xl sm:text-6xl md:text-7xl lg:text-8xl font-normal tracking-tight text-white leading-[1.05] sm:leading-[1.08] max-w-3xl"
        >
          Crafting <span className="italic font-light text-[#e5c07b]">Elegance</span> in Motion.
        </motion.h1>

        {/* Personalized Supporting Statement */}
        <motion.p
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.45, ease: "easeOut" }}
          className="mt-6 text-sm sm:text-base md:text-lg text-white/75 max-w-2xl font-sans-clean font-normal leading-relaxed"
        >
          {CREATOR_DATA.supportingStatement}
        </motion.p>

        {/* Dual Primary CTA Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6, ease: "easeOut" }}
          className="flex flex-wrap items-center justify-center gap-3.5 sm:gap-4 mt-8"
        >
          <a
            href="#featured"
            className="group cursor-pointer inline-flex items-center gap-2 px-7 py-3.5 rounded-full bg-gradient-to-r from-[#d4af37] via-[#e5c07b] to-[#d4af37] text-[#0b0b0e] font-semibold text-xs sm:text-sm tracking-wider uppercase shadow-xl shadow-[#d4af37]/20 hover:scale-[1.03] active:scale-[0.98] transition-all duration-300"
          >
            <span>Explore The Gallery</span>
            <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </a>

          <a
            href={CREATOR_DATA.socials.instagram}
            target="_blank"
            rel="noopener noreferrer"
            className="cursor-pointer inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-white/10 hover:bg-white/15 border border-white/25 text-white font-medium text-xs sm:text-sm tracking-wide backdrop-blur-md hover:scale-[1.03] active:scale-[0.98] transition-all duration-300"
          >
            <Instagram className="w-4 h-4 text-[#e5c07b]" />
            <span>Follow on Instagram</span>
          </a>

          <button
            onClick={() => onPlayFeaturedVideo("OclR3AtLDug")}
            className="cursor-pointer inline-flex items-center gap-2 px-5 py-3.5 rounded-full bg-[#143d34]/80 hover:bg-[#143d34] border border-[#d4af37]/40 text-[#f7e4be] font-medium text-xs sm:text-sm tracking-wide backdrop-blur-md hover:scale-[1.03] active:scale-[0.98] transition-all duration-300"
          >
            <Play className="w-3.5 h-3.5 fill-[#e5c07b] text-[#e5c07b]" />
            <span>Watch Viral Era Reel</span>
          </button>
        </motion.div>
      </div>

      {/* Magazine Editorial Marquee / Highlight Strip at the bottom */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.75, ease: "easeOut" }}
        className="relative z-10 w-full border-t border-white/10 bg-black/40 backdrop-blur-md py-4 sm:py-5 px-4"
      >
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-[#d4af37] font-sans-clean font-semibold uppercase tracking-widest text-[10px]">
            <span className="w-1.5 h-1.5 rounded-full bg-[#d4af37] animate-ping" />
            <span>Editorial Hallmarks</span>
          </div>

          <div className="flex items-center justify-center gap-4 sm:gap-8 flex-wrap text-white/70 font-sans-clean text-xs">
            {editorialTags.map((tag, idx) => (
              <span
                key={tag}
                className="flex items-center gap-2 tracking-wide font-medium hover:text-[#e5c07b] transition-colors"
              >
                {idx > 0 && <span className="text-[#d4af37]/40 hidden sm:inline">•</span>}
                {tag}
              </span>
            ))}
          </div>

          <a
            href="#about"
            className="hidden md:flex items-center gap-1.5 text-white/50 hover:text-white transition-colors text-[11px] uppercase tracking-wider"
          >
            <span>Scroll Down</span>
            <ArrowDown className="w-3.5 h-3.5 animate-bounce" />
          </a>
        </div>
      </motion.div>
    </section>
  );
}
