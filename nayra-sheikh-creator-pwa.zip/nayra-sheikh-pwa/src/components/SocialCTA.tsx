import React from 'react';
import { motion } from 'framer-motion';
import { Instagram, Youtube, ArrowUpRight, Sparkles } from 'lucide-react';
import { CREATOR_DATA } from '../data/creator';

export default function SocialCTA() {
  return (
    <section className="relative py-28 sm:py-36 bg-[#08080a] overflow-hidden text-center">
      {/* Background imagery with subtle movement */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1518895949257-7621c3c786d7?auto=format&fit=crop&w=2000&q=80"
          alt="Follow The Journey Background"
          className="w-full h-full object-cover opacity-20 scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#0b0b0e] via-transparent to-[#0b0b0e]" />
        <div className="absolute inset-0 bg-radial-[ellipse_at_center] from-[#143d34]/40 via-transparent to-[#0b0b0e]/95" />
      </div>

      <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/5 border border-white/15 text-xs font-semibold tracking-[0.25em] text-[#d4af37] uppercase font-sans-clean mb-6 backdrop-blur-md"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>JOIN THE COMMUNITY</span>
        </motion.div>

        <motion.h2
          initial={{ opacity: 0, y: 25 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.15 }}
          className="font-editorial text-5xl sm:text-7xl lg:text-8xl font-normal text-white leading-none tracking-tight"
        >
          Follow the <span className="italic text-[#e5c07b]">journey.</span>
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="mt-6 text-sm sm:text-base md:text-lg text-white/70 font-sans-clean max-w-xl mx-auto leading-relaxed"
        >
          Experience new ethnic couture lookbooks, soulful audio poetry, and candid moments as they unfold in real time.
        </motion.p>

        {/* Action Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 25 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.45 }}
          className="flex flex-wrap items-center justify-center gap-4 sm:gap-6 mt-10"
        >
          <a
            href={CREATOR_DATA.socials.instagram}
            target="_blank"
            rel="noopener noreferrer"
            className="cursor-pointer inline-flex items-center gap-3 px-8 py-4 rounded-full bg-gradient-to-r from-pink-600 via-rose-600 to-purple-700 text-white font-semibold text-xs sm:text-sm uppercase tracking-wider shadow-2xl shadow-rose-900/30 hover:scale-[1.04] active:scale-[0.98] transition-all duration-300"
          >
            <Instagram className="w-4 h-4" />
            <span>Instagram / @nayrasheikh3552</span>
            <ArrowUpRight className="w-4 h-4" />
          </a>

          <a
            href={CREATOR_DATA.socials.youtube}
            target="_blank"
            rel="noopener noreferrer"
            className="cursor-pointer inline-flex items-center gap-3 px-8 py-4 rounded-full bg-red-600 hover:bg-red-700 text-white font-semibold text-xs sm:text-sm uppercase tracking-wider shadow-2xl shadow-red-950/40 hover:scale-[1.04] active:scale-[0.98] transition-all duration-300"
          >
            <Youtube className="w-4 h-4 fill-current" />
            <span>YouTube / @Nayrasheikh3552</span>
            <ArrowUpRight className="w-4 h-4" />
          </a>
        </motion.div>
      </div>
    </section>
  );
}
