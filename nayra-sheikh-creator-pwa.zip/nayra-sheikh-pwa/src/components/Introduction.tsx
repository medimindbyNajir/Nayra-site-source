import React from 'react';
import { motion } from 'framer-motion';
import { Sparkles, Heart, Quote, ArrowUpRight } from 'lucide-react';
import { CREATOR_DATA } from '../data/creator';

export default function Introduction() {
  return (
    <section id="about" className="relative py-20 sm:py-32 bg-[#0e0e12] overflow-hidden border-b border-white/5">
      {/* Subtle background ambient blur */}
      <div className="absolute top-1/2 left-0 -translate-y-1/2 w-96 h-96 bg-[#143d34]/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-80 h-80 bg-[#d4af37]/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* Left Column: Large Editorial Portrait with asymmetric framing */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="lg:col-span-5 relative"
          >
            {/* Background offset card border (Gallery Storefront style) */}
            <div className="absolute -inset-3 sm:-inset-4 rounded-3xl border border-[#d4af37]/30 bg-gradient-to-br from-[#143d34]/30 via-transparent to-[#d4af37]/10 -rotate-2 pointer-events-none" />

            <div className="relative rounded-2xl overflow-hidden shadow-2xl bg-[#121217] border border-white/10 group">
              <img
                src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=1000&q=85"
                alt="Nayra Sheikh Portrait"
                className="w-full aspect-[4/5] object-cover object-top transition-transform duration-700 group-hover:scale-105"
              />

              {/* Gradient overlay at bottom of photo */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#0b0b0e] via-transparent to-transparent opacity-80" />

              {/* Float badge */}
              <div className="absolute bottom-5 left-5 right-5 p-4 rounded-xl bg-black/60 backdrop-blur-md border border-white/15">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-editorial text-lg text-white font-bold tracking-wide">Nayra Sheikh</p>
                    <p className="text-xs text-[#d4af37] font-sans-clean font-medium tracking-wider uppercase">Visual Storyteller & Creator</p>
                  </div>
                  <div className="w-9 h-9 rounded-full bg-[#d4af37]/20 border border-[#d4af37]/50 flex items-center justify-center text-[#e5c07b]">
                    <Sparkles className="w-4 h-4" />
                  </div>
                </div>
              </div>
            </div>

            {/* Floating quote badge */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 0.4, duration: 0.6 }}
              className="absolute -bottom-6 -right-2 sm:-right-6 max-w-xs p-4 rounded-2xl bg-[#1a1a22] border border-[#d4af37]/40 shadow-xl backdrop-blur-xl hidden sm:block"
            >
              <div className="flex items-start gap-3">
                <Quote className="w-5 h-5 text-[#d4af37] shrink-0 mt-0.5" />
                <p className="text-xs text-white/90 italic font-editorial leading-relaxed">
                  "Mere paas aisa dil hai jo kisi ko takleef dene se inkaar karta hai."
                </p>
              </div>
            </motion.div>
          </motion.div>

          {/* Right Column: Editorial Typography & Grounded Bio */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
            className="lg:col-span-7 flex flex-col items-start"
          >
            {/* Small Eyebrow Label */}
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#143d34]/60 border border-[#143d34] text-[#a0eac9] text-xs font-semibold tracking-[0.2em] uppercase mb-4">
              <span className="w-1.5 h-1.5 rounded-full bg-[#3dc789]" />
              <span>THE CREATOR</span>
            </div>

            {/* Large Editorial Heading */}
            <h2 className="font-editorial text-3xl sm:text-5xl lg:text-6xl font-normal tracking-tight text-white leading-tight">
              More than a profile. <br />
              <span className="italic text-[#e5c07b]">A sanctuary of grace.</span>
            </h2>

            {/* Grounded Creator Bio based on real content */}
            <div className="mt-6 space-y-4 text-white/75 font-sans-clean text-sm sm:text-base leading-relaxed">
              <p>
                {CREATOR_DATA.bioFull[0]}
              </p>
              <p>
                {CREATOR_DATA.bioFull[1]}
              </p>
              <p>
                {CREATOR_DATA.bioFull[2]}
              </p>
            </div>

            {/* Content descriptor based on verified channels */}
            <div className="mt-8 p-4 rounded-xl bg-white/[0.04] border border-white/10 w-full flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-[#143d34] flex items-center justify-center text-[#d4af37] border border-[#d4af37]/30">
                  <Heart className="w-5 h-5 fill-current" />
                </div>
                <div>
                  <p className="text-xs uppercase tracking-wider text-white/50 font-semibold font-sans-clean">
                    Content Anchor
                  </p>
                  <p className="text-xs sm:text-sm font-medium text-white">
                    Verified presence on Instagram & YouTube Shorts
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <a
                  href={CREATOR_DATA.socials.instagram}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-medium text-white transition-colors"
                >
                  <span>@nayrasheikh3552</span>
                  <ArrowUpRight className="w-3 h-3 text-[#d4af37]" />
                </a>
              </div>
            </div>

          </motion.div>

        </div>
      </div>
    </section>
  );
}
