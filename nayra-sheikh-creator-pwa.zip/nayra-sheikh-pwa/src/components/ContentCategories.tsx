import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowUpRight, Sparkles, Layers } from 'lucide-react';
import { CONTENT_CATEGORIES } from '../data/creator';

export default function ContentCategories() {
  const [hoveredId, setHoveredId] = useState<string | null>(null);

  return (
    <section id="categories" className="py-20 sm:py-32 bg-[#0e0e12] relative overflow-hidden border-t border-white/5">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 sm:mb-16 gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-xs font-semibold tracking-[0.2em] text-[#d4af37] uppercase font-sans-clean mb-3">
              <Layers className="w-3.5 h-3.5" />
              <span>COLLECTIONS & THEMES</span>
            </div>
            <h2 className="font-editorial text-4xl sm:text-5xl lg:text-6xl font-normal text-white">
              Content <span className="italic text-[#e5c07b]">Categories.</span>
            </h2>
            <p className="mt-3 text-sm text-white/60 font-sans-clean max-w-lg">
              Explore the four creative dimensions that define Nayra Sheikh’s social media universe.
            </p>
          </div>
        </div>

        {/* Gallery Storefront Collection-style panels */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-6 min-h-[480px]">
          {CONTENT_CATEGORIES.map((cat, idx) => (
            <motion.div
              key={cat.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: idx * 0.12 }}
              onMouseEnter={() => setHoveredId(cat.id)}
              onMouseLeave={() => setHoveredId(null)}
              className="group relative rounded-3xl overflow-hidden bg-[#121217] border border-white/10 hover:border-[#d4af37]/50 shadow-2xl transition-all duration-500 flex flex-col justify-between cursor-pointer min-h-[440px] sm:min-h-[480px]"
            >
              {/* Background Cover Image */}
              <img
                src={cat.image}
                alt={cat.title}
                className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
              />

              {/* Gradient masks */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#0b0b0e] via-[#0b0b0e]/60 to-black/30 group-hover:via-[#0b0b0e]/40 transition-colors duration-500" />

              {/* Top Bar with Number & Badge */}
              <div className="relative z-10 p-5 flex items-center justify-between">
                <span className="font-editorial text-2xl font-bold text-white/80 group-hover:text-[#e5c07b] transition-colors">
                  0{idx + 1}
                </span>
                <span className="px-2.5 py-1 rounded-full bg-black/60 border border-white/10 text-[10px] uppercase tracking-wider text-[#f7e4be] font-sans-clean backdrop-blur-md">
                  {cat.countLabel}
                </span>
              </div>

              {/* Center Rotated Vertical Typography Label (Gallery Storefront style) */}
              <div className="relative z-10 px-5 flex-1 flex items-center justify-end">
                <span className="vertical-rl transform rotate-180 font-editorial text-xl sm:text-2xl tracking-widest uppercase text-white/40 group-hover:text-[#e5c07b] transition-colors select-none">
                  {cat.title}
                </span>
              </div>

              {/* Bottom Content & Hover Expansion */}
              <div className="relative z-10 p-6 bg-gradient-to-t from-black via-black/80 to-transparent">
                <p className="text-xs uppercase tracking-wider text-[#d4af37] font-semibold font-sans-clean mb-1">
                  {cat.tagline}
                </p>
                <h3 className="font-editorial text-2xl text-white font-normal leading-tight group-hover:text-[#e5c07b] transition-colors">
                  {cat.title}
                </h3>
                <p className="mt-2 text-xs text-white/70 font-sans-clean line-clamp-2">
                  {cat.description}
                </p>

                <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between text-xs text-[#e5c07b]">
                  <span className="font-medium tracking-wide">Explore Reel Theme</span>
                  <div className="w-8 h-8 rounded-full bg-white/10 group-hover:bg-[#d4af37] group-hover:text-black flex items-center justify-center transition-all duration-300">
                    <ArrowUpRight className="w-4 h-4" />
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}
