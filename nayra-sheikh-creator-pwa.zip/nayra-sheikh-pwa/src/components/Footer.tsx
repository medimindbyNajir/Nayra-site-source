import React from 'react';
import { Instagram, Youtube, ArrowUp, Sparkles } from 'lucide-react';
import { CREATOR_DATA } from '../data/creator';

export default function Footer() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const navLinks = [
    { label: "Home", href: "#hero" },
    { label: "About", href: "#about" },
    { label: "Featured", href: "#featured" },
    { label: "Instagram", href: "#instagram" },
    { label: "YouTube", href: "#youtube" },
    { label: "Categories", href: "#categories" },
    { label: "Collaborate", href: "#collaborate" },
  ];

  return (
    <footer className="bg-[#070709] border-t border-white/10 text-white/70 py-16 px-4 sm:px-6 relative overflow-hidden">
      <div className="max-w-6xl mx-auto flex flex-col gap-12">
        
        {/* Top Tier */}
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-8 pb-12 border-b border-white/10">
          <div>
            <div className="flex items-center gap-3">
              <span className="font-editorial text-3xl font-bold tracking-wider text-white">
                NAYRA SHEIKH
              </span>
              <span className="w-2 h-2 rounded-full bg-[#d4af37]" />
            </div>
            <p className="mt-2 text-xs sm:text-sm text-white/50 font-sans-clean max-w-sm">
              Creator & Visual Storyteller specializing in South Asian Ethnic Couture, Soulful Poetry & Aesthetic Short-Form Cinema.
            </p>
          </div>

          {/* Social Links */}
          <div className="flex items-center gap-3">
            <a
              href={CREATOR_DATA.socials.instagram}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-xs text-white transition-colors"
            >
              <Instagram className="w-3.5 h-3.5 text-[#d4af37]" />
              <span>Instagram</span>
            </a>
            <a
              href={CREATOR_DATA.socials.youtube}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-xs text-white transition-colors"
            >
              <Youtube className="w-3.5 h-3.5 text-red-500" />
              <span>YouTube</span>
            </a>
          </div>
        </div>

        {/* Middle Tier: Navigation Links */}
        <div className="flex flex-wrap items-center justify-center gap-6 sm:gap-10 text-xs uppercase tracking-widest font-sans-clean font-medium">
          {navLinks.map((link) => (
            <a
              key={link.label}
              href={link.href}
              className="text-white/60 hover:text-[#e5c07b] transition-colors"
            >
              {link.label}
            </a>
          ))}
        </div>

        {/* Bottom Tier: Copyright & Back to Top */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-8 text-xs text-white/40 font-sans-clean">
          <p>
            © {new Date().getFullYear()} Nayra Sheikh. All rights reserved.
          </p>

          <p className="text-[11px] text-white/30 text-center sm:text-right">
            Crafted with editorial reverence • PWA Enabled • Progressive Web Application
          </p>

          <button
            onClick={scrollToTop}
            className="cursor-pointer inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/5 hover:bg-white/10 text-white/70 hover:text-white transition-colors"
          >
            <span>Back to top</span>
            <ArrowUp className="w-3.5 h-3.5" />
          </button>
        </div>

      </div>
    </footer>
  );
}
