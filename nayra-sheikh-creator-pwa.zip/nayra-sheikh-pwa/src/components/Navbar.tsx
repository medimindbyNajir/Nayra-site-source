import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Instagram, Youtube, Menu, X, ArrowUpRight } from 'lucide-react';
import { CREATOR_DATA } from '../data/creator';

interface NavbarProps {
  onOpenContact: () => void;
}

export default function Navbar({ onOpenContact }: NavbarProps) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 40);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: "Home", href: "#hero" },
    { label: "About", href: "#about" },
    { label: "Featured", href: "#featured" },
    { label: "Instagram", href: "#instagram" },
    { label: "YouTube", href: "#youtube" },
    { label: "Categories", href: "#categories" },
    { label: "Collaborate", href: "#collaborate" },
  ];

  return (
    <>
      <header className="fixed top-0 left-0 right-0 z-50 flex justify-center px-4 sm:px-6 transition-all duration-500 py-3 sm:py-5">
        <motion.nav
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className={`flex items-center justify-between gap-4 sm:gap-8 px-5 sm:px-7 rounded-full transition-all duration-500 max-w-5xl w-full border ${
            scrolled
              ? 'bg-[#0f0f14]/85 border-[#d4af37]/30 backdrop-blur-xl shadow-2xl shadow-black/50 py-2.5'
              : 'bg-white/10 border-white/20 backdrop-blur-md shadow-lg shadow-black/20 py-3 sm:py-3.5'
          }`}
        >
          {/* Logo / Brandmark */}
          <a
            href="#hero"
            className="flex items-center gap-2 group text-decoration-none focus:outline-none"
          >
            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-[#143d34] to-[#d4af37]/80 flex items-center justify-center border border-[#d4af37]/40 shadow-inner group-hover:scale-105 transition-transform duration-300">
              <span className="font-editorial text-sm font-bold text-white tracking-widest">NS</span>
            </div>
            <div className="flex flex-col">
              <span className="font-editorial text-lg sm:text-xl font-bold tracking-wider text-white group-hover:text-[#e5c07b] transition-colors duration-300">
                NAYRA SHEIKH
              </span>
              <span className="text-[9px] tracking-[0.25em] text-[#d4af37] uppercase -mt-1 font-sans-clean font-medium">
                Creator & Couture
              </span>
            </div>
          </a>

          {/* Desktop Navigation Links */}
          <div className="hidden lg:flex items-center gap-6">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="text-xs tracking-wider uppercase font-medium text-white/75 hover:text-[#e5c07b] transition-colors duration-200"
              >
                {link.label}
              </a>
            ))}
          </div>

          {/* Right Action Icons & Primary CTA */}
          <div className="hidden sm:flex items-center gap-3">
            <a
              href={CREATOR_DATA.socials.instagram}
              target="_blank"
              rel="noopener noreferrer"
              className="w-8 h-8 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white/80 hover:text-[#d4af37] hover:border-[#d4af37]/50 hover:bg-white/10 transition-all duration-200"
              aria-label="Instagram Profile"
              title="Nayra Sheikh on Instagram"
            >
              <Instagram className="w-4 h-4" />
            </a>
            <a
              href={CREATOR_DATA.socials.youtube}
              target="_blank"
              rel="noopener noreferrer"
              className="w-8 h-8 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white/80 hover:text-[#ff4444] hover:border-[#ff4444]/50 hover:bg-white/10 transition-all duration-200"
              aria-label="YouTube Channel"
              title="Nayra Sheikh on YouTube"
            >
              <Youtube className="w-4 h-4" />
            </a>
            <button
              onClick={onOpenContact}
              className="cursor-pointer ml-1 inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs font-semibold tracking-wide bg-gradient-to-r from-[#d4af37] to-[#e5c07b] text-[#0b0b0e] hover:shadow-lg hover:shadow-[#d4af37]/25 hover:scale-[1.02] active:scale-[0.98] transition-all duration-200"
            >
              <span>Connect</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Mobile Hamburger Toggle */}
          <div className="flex sm:hidden items-center gap-2">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="w-9 h-9 rounded-full bg-white/10 border border-white/20 flex items-center justify-center text-white focus:outline-none"
              aria-label="Toggle Menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </motion.nav>
      </header>

      {/* Mobile Drawer */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-x-4 top-20 z-40 bg-[#121217]/95 border border-[#d4af37]/30 rounded-3xl p-6 shadow-2xl backdrop-blur-2xl sm:hidden flex flex-col gap-4 text-center"
          >
            <div className="flex flex-col gap-3 pb-4 border-b border-white/10">
              {navLinks.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className="text-sm font-medium tracking-wide uppercase text-white/85 hover:text-[#e5c07b] py-1 transition-colors"
                >
                  {link.label}
                </a>
              ))}
            </div>

            <div className="flex items-center justify-center gap-4 pt-2">
              <a
                href={CREATOR_DATA.socials.instagram}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/15 text-xs text-white"
              >
                <Instagram className="w-4 h-4 text-[#d4af37]" />
                <span>Instagram</span>
              </a>
              <a
                href={CREATOR_DATA.socials.youtube}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/15 text-xs text-white"
              >
                <Youtube className="w-4 h-4 text-red-500" />
                <span>YouTube</span>
              </a>
            </div>

            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenContact();
              }}
              className="w-full mt-2 py-3 rounded-full bg-gradient-to-r from-[#d4af37] to-[#e5c07b] text-[#0b0b0e] font-semibold text-sm tracking-wide shadow-lg shadow-[#d4af37]/20"
            >
              Work With Nayra
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
