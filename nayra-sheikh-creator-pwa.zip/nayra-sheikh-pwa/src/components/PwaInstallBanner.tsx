import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Download, X, Sparkles, Smartphone } from 'lucide-react';

export default function PwaInstallBanner() {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [showBanner, setShowBanner] = useState(false);

  useEffect(() => {
    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setShowBanner(true);
    };

    window.addEventListener('beforeinstallprompt', handler);

    // Also show brief banner if on mobile standalone capable browser
    const isStandalone = window.matchMedia('(display-mode: standalone)').matches || (window.navigator as any).standalone;
    if (isStandalone) {
      setShowBanner(false);
    }

    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const handleInstall = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        setShowBanner(false);
      }
      setDeferredPrompt(null);
    } else {
      // Manual instruction fallback
      alert('To install Nayra Sheikh on iOS, tap the Share icon and select "Add to Home Screen". On Android, tap the three dots in Chrome and select "Install app".');
      setShowBanner(false);
    }
  };

  return (
    <AnimatePresence>
      {showBanner && (
        <motion.div
          initial={{ opacity: 0, y: 50, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 50, scale: 0.95 }}
          transition={{ duration: 0.4 }}
          className="fixed bottom-5 right-5 left-5 sm:left-auto sm:max-w-md z-50 p-4 rounded-2xl bg-[#14141d]/95 border border-[#d4af37]/40 shadow-2xl backdrop-blur-xl flex items-center justify-between gap-4 text-white"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#143d34] to-[#d4af37]/80 flex items-center justify-center shrink-0 border border-[#d4af37]/50 shadow-md">
              <Smartphone className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="text-xs font-semibold text-white tracking-wide">
                Install Nayra Sheikh App
              </p>
              <p className="text-[11px] text-white/60">
                Native app experience, offline access & instant reels
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleInstall}
              className="cursor-pointer px-3.5 py-1.5 rounded-full bg-[#d4af37] text-[#0b0b0e] text-xs font-bold uppercase tracking-wider hover:bg-[#e5c07b] transition-colors whitespace-nowrap"
            >
              Install
            </button>
            <button
              onClick={() => setShowBanner(false)}
              className="cursor-pointer p-1.5 rounded-full text-white/50 hover:text-white transition-colors"
              aria-label="Dismiss install banner"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
