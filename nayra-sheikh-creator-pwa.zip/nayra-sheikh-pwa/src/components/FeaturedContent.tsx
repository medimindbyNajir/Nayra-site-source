import React from 'react';
import { motion } from 'framer-motion';
import { Play, ArrowUpRight, Sparkles, Eye, ThumbsUp } from 'lucide-react';
import { FEATURED_CONTENT } from '../data/creator';

interface FeaturedContentProps {
  onPlayVideo: (youtubeId: string) => void;
}

export default function FeaturedContent({ onPlayVideo }: FeaturedContentProps) {
  const primaryItem = FEATURED_CONTENT[0];
  const secondaryItems = [FEATURED_CONTENT[1], FEATURED_CONTENT[2]];
  const tertiaryItems = [FEATURED_CONTENT[3], FEATURED_CONTENT[4], FEATURED_CONTENT[5]];

  return (
    <section id="featured" className="py-20 sm:py-32 bg-[#0b0b0e] relative overflow-hidden">
      {/* Decorative vertical editorial line */}
      <div className="absolute top-0 right-16 w-px h-full bg-gradient-to-b from-transparent via-[#d4af37]/20 to-transparent hidden lg:block" />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 sm:mb-16 gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-xs font-semibold tracking-[0.2em] text-[#d4af37] uppercase font-sans-clean mb-3">
              <Sparkles className="w-3.5 h-3.5" />
              <span>CURATED SELECTION</span>
            </div>
            <h2 className="font-editorial text-4xl sm:text-5xl lg:text-6xl font-normal text-white">
              Featured <span className="italic text-[#e5c07b]">Highlights.</span>
            </h2>
          </div>
          <p className="text-sm text-white/60 font-sans-clean max-w-md">
            A hand-picked anthology of Nayra's most impactful visual storytelling, from regal velvet silhouettes to reflective poetry.
          </p>
        </div>

        {/* Asymmetric Gallery Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 sm:gap-8">
          
          {/* Large Hero Card (Left, span 7) */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="lg:col-span-7 group relative rounded-3xl overflow-hidden bg-[#121217] border border-white/10 hover:border-[#d4af37]/40 shadow-2xl transition-all duration-500 cursor-pointer flex flex-col justify-end min-h-[460px] sm:min-h-[540px]"
            onClick={() => primaryItem.youtubeId && onPlayVideo(primaryItem.youtubeId)}
          >
            <img
              src={primaryItem.image}
              alt={primaryItem.title}
              className="absolute inset-0 w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0b0b0e] via-[#0b0b0e]/50 to-transparent opacity-95" />

            {/* Top Badges */}
            <div className="absolute top-5 left-5 right-5 flex items-center justify-between z-10">
              <span className="px-3.5 py-1.5 rounded-full bg-[#143d34]/90 border border-[#d4af37]/40 text-[#f7e4be] text-xs font-semibold tracking-wider uppercase backdrop-blur-md">
                {primaryItem.badge}
              </span>
              <div className="flex items-center gap-2">
                {primaryItem.views && (
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-black/60 border border-white/10 text-white/80 text-xs backdrop-blur-md">
                    <Eye className="w-3.5 h-3.5 text-[#d4af37]" />
                    <span>{primaryItem.views}</span>
                  </span>
                )}
                {primaryItem.likes && (
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-black/60 border border-white/10 text-white/80 text-xs backdrop-blur-md">
                    <ThumbsUp className="w-3.5 h-3.5 text-[#d4af37]" />
                    <span>{primaryItem.likes}</span>
                  </span>
                )}
              </div>
            </div>

            {/* Content Details */}
            <div className="relative z-10 p-6 sm:p-8">
              <span className="text-xs uppercase tracking-widest text-[#d4af37] font-semibold font-sans-clean">
                {primaryItem.category} // {primaryItem.platform}
              </span>
              <h3 className="font-editorial text-2xl sm:text-3xl lg:text-4xl text-white font-normal mt-2 leading-tight group-hover:text-[#e5c07b] transition-colors">
                {primaryItem.title}
              </h3>
              {primaryItem.quote && (
                <p className="mt-3 text-xs sm:text-sm text-white/80 italic font-editorial max-w-xl">
                  "{primaryItem.quote}"
                </p>
              )}
              <p className="mt-2 text-xs sm:text-sm text-white/60 font-sans-clean line-clamp-2 max-w-xl">
                {primaryItem.description}
              </p>

              <div className="mt-6 flex items-center justify-between pt-4 border-t border-white/10">
                <div className="inline-flex items-center gap-2 text-xs font-semibold tracking-wider uppercase text-[#e5c07b] group-hover:translate-x-1 transition-transform">
                  <Play className="w-4 h-4 fill-current" />
                  <span>Watch Video Reel</span>
                </div>
                <div className="w-10 h-10 rounded-full bg-white/10 border border-white/20 flex items-center justify-center text-white group-hover:bg-[#d4af37] group-hover:text-[#0b0b0e] transition-all">
                  <ArrowUpRight className="w-5 h-5" />
                </div>
              </div>
            </div>
          </motion.div>

          {/* Two Stacked Cards (Right, span 5) */}
          <div className="lg:col-span-5 flex flex-col gap-6 sm:gap-8">
            {secondaryItems.map((item, idx) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.7, delay: idx * 0.15 }}
                className="group relative rounded-3xl overflow-hidden bg-[#121217] border border-white/10 hover:border-[#d4af37]/40 shadow-xl transition-all duration-500 cursor-pointer flex flex-col justify-end min-h-[250px] sm:min-h-[260px]"
                onClick={() => item.youtubeId && onPlayVideo(item.youtubeId)}
              >
                <img
                  src={item.image}
                  alt={item.title}
                  className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0b0b0e] via-[#0b0b0e]/60 to-transparent opacity-95" />

                <div className="absolute top-4 left-4 right-4 flex items-center justify-between z-10">
                  <span className="px-2.5 py-1 rounded-full bg-black/60 border border-[#d4af37]/30 text-[#f7e4be] text-[10px] font-semibold tracking-wider uppercase backdrop-blur-md">
                    {item.badge}
                  </span>
                  {item.views && (
                    <span className="text-[11px] text-white/70 font-sans-clean">
                      {item.views}
                    </span>
                  )}
                </div>

                <div className="relative z-10 p-5 sm:p-6">
                  <span className="text-[10px] uppercase tracking-widest text-[#d4af37] font-semibold font-sans-clean">
                    {item.category}
                  </span>
                  <h4 className="font-editorial text-lg sm:text-xl text-white font-normal mt-1 leading-snug group-hover:text-[#e5c07b] transition-colors">
                    {item.title}
                  </h4>
                  {item.quote && (
                    <p className="mt-1 text-xs text-white/70 italic font-editorial line-clamp-1">
                      "{item.quote}"
                    </p>
                  )}
                  <div className="mt-4 flex items-center justify-between pt-3 border-t border-white/10">
                    <span className="inline-flex items-center gap-1.5 text-xs text-[#e5c07b] font-medium">
                      <Play className="w-3.5 h-3.5 fill-current" />
                      <span>Preview</span>
                    </span>
                    <ArrowUpRight className="w-4 h-4 text-white/70 group-hover:text-[#e5c07b] group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

        </div>

        {/* Horizontal Row Underneath (3 Cards) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8 mt-8">
          {tertiaryItems.map((item, idx) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 25 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: idx * 0.1 }}
              className="group relative rounded-2xl overflow-hidden bg-[#121217] border border-white/10 hover:border-[#d4af37]/30 shadow-lg transition-all duration-300 cursor-pointer flex flex-col justify-between"
              onClick={() => item.youtubeId && onPlayVideo(item.youtubeId)}
            >
              <div className="relative aspect-[16/10] overflow-hidden">
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#121217] via-transparent to-transparent opacity-80" />
                <div className="absolute top-3 left-3">
                  <span className="px-2 py-0.5 rounded-full bg-black/60 border border-white/10 text-white/80 text-[10px] font-sans-clean font-medium backdrop-blur-md">
                    {item.badge}
                  </span>
                </div>
                <div className="absolute bottom-3 right-3 w-8 h-8 rounded-full bg-[#143d34]/90 border border-[#d4af37]/40 flex items-center justify-center text-[#e5c07b] shadow-lg">
                  <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
                </div>
              </div>

              <div className="p-5 flex flex-col justify-between flex-1">
                <div>
                  <span className="text-[10px] uppercase tracking-wider text-[#d4af37] font-semibold font-sans-clean">
                    {item.category}
                  </span>
                  <h4 className="font-editorial text-lg text-white font-normal mt-1 leading-snug group-hover:text-[#e5c07b] transition-colors">
                    {item.title}
                  </h4>
                  {item.quote && (
                    <p className="mt-1 text-xs text-white/60 italic font-editorial">
                      "{item.quote}"
                    </p>
                  )}
                </div>

                <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between text-xs text-white/60">
                  <span>{item.views || "Curated Short"}</span>
                  <span className="text-[#e5c07b] font-medium flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                    <span>Watch</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}
