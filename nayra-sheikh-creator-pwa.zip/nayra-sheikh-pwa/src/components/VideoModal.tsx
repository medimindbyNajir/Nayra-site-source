import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Youtube, ArrowUpRight } from 'lucide-react';
import { YOUTUBE_VIDEOS } from '../data/creator';

interface VideoModalProps {
  youtubeId: string | null;
  onClose: () => void;
}

export default function VideoModal({ youtubeId, onClose }: VideoModalProps) {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (youtubeId) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => {
      document.body.style.overflow = 'auto';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [youtubeId, onClose]);

  if (!youtubeId) return null;

  const currentVideo = YOUTUBE_VIDEOS.find(v => v.youtubeId === youtubeId);

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 md:p-10">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-black/85 backdrop-blur-xl"
        />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, scale: 0.92, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.92, y: 20 }}
          transition={{ duration: 0.3 }}
          className="relative z-10 w-full max-w-4xl bg-[#121217] border border-white/15 rounded-3xl overflow-hidden shadow-2xl flex flex-col"
        >
          {/* Header */}
          <div className="p-4 sm:p-5 flex items-center justify-between border-b border-white/10 bg-black/40">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-red-600/20 border border-red-500/40 flex items-center justify-center text-red-500">
                <Youtube className="w-4 h-4 fill-current" />
              </div>
              <div>
                <h4 className="text-sm font-semibold text-white truncate max-w-xs sm:max-w-md">
                  {currentVideo ? currentVideo.title : 'Nayra Sheikh — YouTube Short'}
                </h4>
                <p className="text-[11px] text-white/50">Official YouTube Player</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <a
                href={`https://m.youtube.com/watch?v=${youtubeId}`}
                target="_blank"
                rel="noopener noreferrer"
                className="hidden sm:inline-flex items-center gap-1 px-3 py-1.5 rounded-full bg-white/10 hover:bg-white/15 text-xs text-white/80 transition-colors"
              >
                <span>Open in YouTube</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </a>

              <button
                onClick={onClose}
                className="cursor-pointer w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors"
                aria-label="Close video player"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Responsive Video Container */}
          <div className="relative aspect-video w-full bg-black">
            <iframe
              src={`https://www.youtube-nocookie.com/embed/${youtubeId}?autoplay=1&rel=0&modestbranding=1`}
              title="YouTube video player"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              allowFullScreen
              className="absolute inset-0 w-full h-full border-0"
            />
          </div>

          {/* Footer note */}
          {currentVideo?.quote && (
            <div className="p-4 bg-black/50 border-t border-white/10 text-xs text-white/70 italic text-center font-editorial">
              "{currentVideo.quote}"
            </div>
          )}
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
