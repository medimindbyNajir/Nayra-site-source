import React from 'react';
import { motion } from 'framer-motion';
import { Sparkles, CheckCircle2, ArrowUpRight, Mail, MessageSquare } from 'lucide-react';
import { COLLABORATION_SERVICES } from '../data/creator';

interface CollaborationSectionProps {
  onOpenContact: () => void;
}

export default function CollaborationSection({ onOpenContact }: CollaborationSectionProps) {
  return (
    <section id="collaborate" className="py-20 sm:py-32 bg-[#0b0b0e] relative overflow-hidden border-t border-white/5">
      {/* Ambient background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-5xl h-96 bg-[#143d34]/20 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 sm:mb-20">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-xs font-semibold tracking-[0.2em] text-[#d4af37] uppercase font-sans-clean mb-4">
            <Sparkles className="w-3.5 h-3.5" />
            <span>BRAND PARTNERSHIPS & MEDIA KIT</span>
          </div>

          <h2 className="font-editorial text-4xl sm:text-6xl lg:text-7xl font-normal text-white leading-tight">
            Let's create something <br />
            <span className="italic text-[#e5c07b]">worth watching.</span>
          </h2>

          <p className="mt-5 text-sm sm:text-base text-white/70 font-sans-clean leading-relaxed">
            Collaborate with Nayra Sheikh for bespoke fashion campaigns, cinematic product storytelling, aesthetic short-form video features, and high-engagement South Asian cultural narratives.
          </p>

          <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
            <button
              onClick={onOpenContact}
              className="cursor-pointer inline-flex items-center gap-2 px-8 py-4 rounded-full bg-gradient-to-r from-[#d4af37] via-[#e5c07b] to-[#d4af37] text-[#0b0b0e] font-semibold text-xs sm:text-sm uppercase tracking-wider shadow-xl shadow-[#d4af37]/20 hover:scale-[1.03] active:scale-[0.98] transition-all duration-300"
            >
              <span>Work With Nayra</span>
              <ArrowUpRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Services / Deliverables Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8">
          {COLLABORATION_SERVICES.map((service, idx) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 25 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: idx * 0.1 }}
              className="p-8 rounded-3xl bg-[#121217] border border-white/10 hover:border-[#d4af37]/40 shadow-xl transition-all duration-300 flex flex-col justify-between group"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-[10px] tracking-widest font-semibold uppercase text-[#d4af37] font-sans-clean px-2.5 py-1 rounded bg-[#d4af37]/10 border border-[#d4af37]/30">
                    {service.tag}
                  </span>
                  <span className="text-xs font-mono text-white/40">0{idx + 1}</span>
                </div>

                <h3 className="font-editorial text-2xl sm:text-3xl text-white font-normal group-hover:text-[#e5c07b] transition-colors">
                  {service.title}
                </h3>

                <p className="mt-3 text-xs sm:text-sm text-white/60 font-sans-clean leading-relaxed">
                  {service.description}
                </p>

                <div className="mt-6 pt-5 border-t border-white/10 space-y-2.5">
                  {service.deliverables.map((d) => (
                    <div key={d} className="flex items-center gap-2.5 text-xs text-white/80 font-sans-clean">
                      <CheckCircle2 className="w-3.5 h-3.5 text-[#3dc789] shrink-0" />
                      <span>{d}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-8 pt-4 border-t border-white/5 flex items-center justify-between">
                <span className="text-xs text-white/50">Custom scope & rights</span>
                <button
                  onClick={onOpenContact}
                  className="cursor-pointer text-xs font-semibold text-[#e5c07b] hover:text-white inline-flex items-center gap-1 transition-colors"
                >
                  <span>Inquire Now</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}
