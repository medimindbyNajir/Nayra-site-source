import React from 'react';
import { motion } from 'framer-motion';
import { Sparkles, Quote, Compass, Feather, ShieldCheck } from 'lucide-react';
import { CREATOR_DATA } from '../data/creator';

export default function AboutSection() {
  const philosophies = [
    {
      icon: Feather,
      title: "Artistry in Craft",
      desc: "Championing hand-embroidered velvet, timeless sharara suits, and authentic South Asian silhouettes with meticulous cinematic poise."
    },
    {
      icon: Compass,
      title: "Soulful Intention",
      desc: "Pairing visuals with poignant dialogues and Sufi melodies that celebrate empathy, gentle forgiveness, and inner tranquility."
    },
    {
      icon: ShieldCheck,
      title: "Faith in the Era",
      desc: "Holding onto patience, resilience, and prayer through life’s unexpected tests — living by the creed 'Himmat hari toh sab haar jaungi'."
    }
  ];

  return (
    <section className="py-20 sm:py-32 bg-[#0b0b0e] relative overflow-hidden border-t border-white/5">
      {/* Editorial Watermark */}
      <div className="absolute top-12 left-6 text-white/[0.02] font-editorial text-[160px] sm:text-[220px] font-bold select-none pointer-events-none leading-none">
        NAYRA
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 relative z-10">
        
        {/* Editorial Layout with Overlapping Visual Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* Left Narrative Text */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="lg:col-span-7 flex flex-col items-start"
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-xs font-semibold tracking-[0.2em] text-[#d4af37] uppercase font-sans-clean mb-4">
              <Sparkles className="w-3.5 h-3.5" />
              <span>THE PHILOSOPHY</span>
            </div>

            <h2 className="font-editorial text-4xl sm:text-5xl lg:text-6xl font-normal text-white leading-tight">
              Behind <span className="italic text-[#e5c07b]">the content.</span>
            </h2>

            <p className="mt-6 text-base sm:text-lg text-white/80 font-editorial italic leading-relaxed max-w-xl">
              {CREATOR_DATA.quote}
            </p>

            <div className="mt-6 space-y-4 text-sm sm:text-base text-white/70 font-sans-clean leading-relaxed max-w-xl">
              <p>
                In a digital landscape often dominated by high-speed noise, Nayra Sheikh crafts a sanctuary of stillness, beauty, and emotional sincerity. Every reel and short is treated not as a quick upload, but as an aesthetic vignette.
              </p>
              <p>
                From sweeping velvet hems rustling across quiet courtyards to heartfelt spoken words that remind viewers to choose gentleness over revenge, Nayra's voice connects with an audience that values depth, tradition, and personal grace.
              </p>
            </div>

            {/* Core Pillars */}
            <div className="mt-10 grid grid-cols-1 sm:grid-cols-3 gap-6 w-full pt-8 border-t border-white/10">
              {philosophies.map((p) => {
                const Icon = p.icon;
                return (
                  <div key={p.title} className="flex flex-col gap-2">
                    <div className="w-10 h-10 rounded-xl bg-[#143d34]/70 border border-[#d4af37]/30 flex items-center justify-center text-[#e5c07b]">
                      <Icon className="w-5 h-5" />
                    </div>
                    <h4 className="font-editorial text-lg text-white font-normal mt-1">
                      {p.title}
                    </h4>
                    <p className="text-xs text-white/60 font-sans-clean leading-relaxed">
                      {p.desc}
                    </p>
                  </div>
                );
              })}
            </div>
          </motion.div>

          {/* Right Visual Layer with Overlapping Editorial Elements */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="lg:col-span-5 relative"
          >
            {/* Main Portrait */}
            <div className="relative rounded-3xl overflow-hidden border border-white/15 shadow-2xl bg-[#121217]">
              <img
                src="https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=1000&q=80"
                alt="Behind The Content"
                className="w-full aspect-[3/4] object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0b0b0e] via-transparent to-transparent opacity-80" />

              <div className="absolute bottom-6 left-6 right-6">
                <span className="text-[10px] tracking-[0.25em] text-[#d4af37] uppercase font-semibold font-sans-clean">
                  CREATOR ESSENCE
                </span>
                <p className="font-editorial text-xl sm:text-2xl text-white font-normal mt-1">
                  "Gentle hands, steadfast prayers, and an enduring devotion to craft."
                </p>
              </div>
            </div>

            {/* Overlapping Mini Card (Gallery Storefront style) */}
            <div className="absolute -bottom-8 -left-6 max-w-xs p-5 rounded-2xl bg-[#14141d]/90 border border-[#d4af37]/30 backdrop-blur-xl shadow-2xl hidden sm:block">
              <div className="flex items-center gap-3 mb-2">
                <Quote className="w-4 h-4 text-[#d4af37]" />
                <span className="text-xs uppercase tracking-wider text-[#d4af37] font-semibold">
                  Personal Mantra
                </span>
              </div>
              <p className="text-xs text-white/80 font-sans-clean leading-relaxed">
                "Never compromise on compassion. Even in silence, let your presence reflect grace."
              </p>
            </div>
          </motion.div>

        </div>

      </div>
    </section>
  );
}
