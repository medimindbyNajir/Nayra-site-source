import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Instagram, ArrowUpRight, Sparkles, Filter } from 'lucide-react';
import { INSTAGRAM_POSTS, CREATOR_DATA } from '../data/creator';

export default function InstagramGallery() {
  const [activeCategory, setActiveCategory] = useState<string>('All');

  const categories = ['All', 'Couture', 'Soulful', 'Resilience', 'Aesthetics'];

  const filteredPosts = activeCategory === 'All'
    ? INSTAGRAM_POSTS
    : INSTAGRAM_POSTS.filter(p => p.category === activeCategory);

  return (
    <section id="instagram" className="py-20 sm:py-32 bg-[#0e0e12] relative overflow-hidden border-t border-b border-white/5">
      {/* Background ambient light */}
      <div className="absolute top-1/3 right-0 w-80 h-80 bg-[#8c2d3e]/15 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 sm:mb-14 gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-xs font-semibold tracking-[0.2em] text-[#d4af37] uppercase font-sans-clean mb-3">
              <Instagram className="w-3.5 h-3.5 text-[#e5c07b]" />
              <span>THE VISUAL DIARY</span>
            </div>
            <h2 className="font-editorial text-4xl sm:text-5xl lg:text-6xl font-normal text-white">
              From <span className="italic text-[#e5c07b]">Instagram.</span>
            </h2>
            <p className="mt-3 text-sm text-white/60 font-sans-clean max-w-lg">
              Regal silhouettes, handcrafted embroidery, tender dialogues, and quiet moments captured through Nayra’s distinctive lens.
            </p>
          </div>

          {/* Filter Tabs */}
          <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap bg-[#14141a] p-1.5 rounded-full border border-white/10 self-start md:self-auto">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`cursor-pointer px-3.5 py-1.5 rounded-full text-xs font-medium tracking-wide transition-all duration-200 ${
                  activeCategory === cat
                    ? 'bg-[#d4af37] text-[#0b0b0e] font-semibold shadow-md shadow-[#d4af37]/20'
                    : 'text-white/70 hover:text-white hover:bg-white/5'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Editorial Masonry-style Grid */}
        <motion.div
          layout
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8"
        >
          <AnimatePresence>
            {filteredPosts.map((post) => (
              <motion.article
                layout
                key={post.id}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.4 }}
                className="group relative rounded-3xl overflow-hidden bg-[#121217] border border-white/10 hover:border-[#d4af37]/40 shadow-xl transition-all duration-300 flex flex-col justify-between"
              >
                {/* Media Container */}
                <div className="relative aspect-[4/5] overflow-hidden">
                  <img
                    src={post.image}
                    alt={post.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#121217] via-transparent to-transparent opacity-85" />
                  
                  {/* Top Overlay Badges */}
                  <div className="absolute top-4 left-4 right-4 flex items-center justify-between">
                    <span className="px-3 py-1 rounded-full bg-black/60 border border-white/15 text-[#f7e4be] text-[11px] font-sans-clean font-medium backdrop-blur-md">
                      {post.category}
                    </span>
                    <a
                      href={post.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-8 h-8 rounded-full bg-white/10 hover:bg-[#d4af37] hover:text-[#0b0b0e] border border-white/20 flex items-center justify-center text-white backdrop-blur-md transition-colors"
                      title="Open on Instagram"
                      aria-label="Open post on Instagram"
                    >
                      <ArrowUpRight className="w-4 h-4" />
                    </a>
                  </div>

                  {/* Aesthetic quote overlay */}
                  <div className="absolute bottom-4 left-4 right-4">
                    <p className="font-editorial text-sm sm:text-base text-white font-medium leading-snug line-clamp-2 italic">
                      "{post.caption}"
                    </p>
                  </div>
                </div>

                {/* Footer Content Card */}
                <div className="p-5 flex flex-col justify-between flex-1">
                  <div>
                    <div className="flex items-center justify-between text-[11px] text-white/50 font-sans-clean mb-2">
                      <span>{post.date}</span>
                      <span className="text-[#d4af37] font-medium">{post.likes}</span>
                    </div>
                    <h3 className="font-editorial text-xl text-white font-normal group-hover:text-[#e5c07b] transition-colors">
                      {post.title}
                    </h3>
                  </div>

                  {/* Hashtags */}
                  <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between">
                    <div className="flex gap-1.5 flex-wrap">
                      {post.tags.slice(0, 2).map(tag => (
                        <span key={tag} className="text-[10px] text-white/40 font-mono">
                          {tag}
                        </span>
                      ))}
                    </div>
                    <a
                      href={post.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs font-semibold text-[#e5c07b] inline-flex items-center gap-1 group-hover:translate-x-1 transition-transform"
                    >
                      <span>Reel</span>
                      <ArrowUpRight className="w-3.5 h-3.5" />
                    </a>
                  </div>
                </div>
              </motion.article>
            ))}
          </AnimatePresence>
        </motion.div>

        {/* Main Section CTA */}
        <div className="mt-14 sm:mt-16 text-center">
          <a
            href={CREATOR_DATA.socials.instagram}
            target="_blank"
            rel="noopener noreferrer"
            className="cursor-pointer inline-flex items-center gap-3 px-8 py-4 rounded-full bg-gradient-to-r from-white/10 via-white/15 to-white/10 hover:bg-white/20 border border-white/25 text-white font-semibold text-xs sm:text-sm uppercase tracking-wider backdrop-blur-md shadow-xl hover:scale-[1.02] active:scale-[0.98] transition-all duration-300"
          >
            <Instagram className="w-4 h-4 text-[#e5c07b]" />
            <span>View Full Instagram Gallery →</span>
          </a>
        </div>

      </div>
    </section>
  );
}
