import React from 'react';
import { motion } from 'framer-motion';
import { CREATOR_DATA } from '../data/creator';

export default function SocialStats() {
  return (
    <section className="relative py-16 bg-[#0b0b0e] border-b border-white/10">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        
        {/* Magazine-style stats grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
          {CREATOR_DATA.metrics.map((metric, idx) => (
            <motion.div
              key={metric.label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: idx * 0.1 }}
              className="relative p-6 rounded-2xl bg-[#121217] border border-white/5 hover:border-[#d4af37]/30 transition-all duration-300 group flex flex-col justify-between"
            >
              <div className="flex items-center justify-between mb-4">
                <span className="text-[10px] tracking-[0.2em] font-semibold text-[#d4af37] uppercase font-sans-clean">
                  0{idx + 1} // {metric.label}
                </span>
                <span className="w-1.5 h-1.5 rounded-full bg-[#d4af37]/40 group-hover:bg-[#d4af37] transition-colors" />
              </div>

              <div>
                <p className="font-editorial text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-white group-hover:text-[#e5c07b] transition-colors">
                  {metric.value}
                </p>
                <p className="mt-2 text-xs sm:text-sm text-white/60 font-sans-clean leading-relaxed">
                  {metric.description}
                </p>
              </div>

              {/* Bottom decorative gold accent bar */}
              <div className="mt-4 w-full h-[1px] bg-white/10 group-hover:bg-gradient-to-r group-hover:from-[#d4af37] group-hover:to-transparent transition-all duration-500" />
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}
