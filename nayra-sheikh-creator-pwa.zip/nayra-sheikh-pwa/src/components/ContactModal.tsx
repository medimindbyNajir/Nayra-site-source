import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Send, Sparkles, CheckCircle2, Mail, MessageSquare } from 'lucide-react';
import { CREATOR_DATA } from '../data/creator';

interface ContactModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function ContactModal({ isOpen, onClose }: ContactModalProps) {
  const [formData, setFormData] = useState({
    name: '',
    brand: '',
    email: '',
    projectType: 'Ethnic Couture Showcase',
    budget: '',
    message: ''
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) return;
    setSubmitted(true);
    setTimeout(() => {
      // simulate completed submission
    }, 400);
  };

  const handleReset = () => {
    setSubmitted(false);
    setFormData({
      name: '',
      brand: '',
      email: '',
      projectType: 'Ethnic Couture Showcase',
      budget: '',
      message: ''
    });
    onClose();
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-black/85 backdrop-blur-xl"
        />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, scale: 0.94, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.94, y: 20 }}
          transition={{ duration: 0.3 }}
          className="relative z-10 w-full max-w-2xl bg-[#121217] border border-[#d4af37]/30 rounded-3xl p-6 sm:p-8 shadow-2xl my-8"
        >
          {/* Close button */}
          <button
            onClick={onClose}
            className="cursor-pointer absolute top-6 right-6 w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors"
            aria-label="Close collaboration modal"
          >
            <X className="w-5 h-5" />
          </button>

          {!submitted ? (
            <div>
              <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-[#d4af37] font-sans-clean mb-2">
                <Sparkles className="w-3.5 h-3.5" />
                <span>DIRECT INQUIRY</span>
              </div>

              <h3 className="font-editorial text-3xl sm:text-4xl text-white font-normal">
                Work with <span className="italic text-[#e5c07b]">Nayra Sheikh.</span>
              </h3>

              <p className="mt-2 text-xs sm:text-sm text-white/60 font-sans-clean">
                Please provide details regarding your brand, proposed campaign timeline, and creative vision.
              </p>

              <form onSubmit={handleSubmit} className="mt-6 space-y-4 font-sans-clean text-xs sm:text-sm">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-white/70 mb-1.5 font-medium">Your Name *</label>
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="e.g. Ayesha Khan"
                      className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-white/30 focus:border-[#d4af37] focus:outline-none transition-colors"
                    />
                  </div>

                  <div>
                    <label className="block text-white/70 mb-1.5 font-medium">Brand / Organization</label>
                    <input
                      type="text"
                      value={formData.brand}
                      onChange={(e) => setFormData({ ...formData, brand: e.target.value })}
                      placeholder="e.g. Aynaa Couture / Boutique"
                      className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-white/30 focus:border-[#d4af37] focus:outline-none transition-colors"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-white/70 mb-1.5 font-medium">Work Email Address *</label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="collab@yourbrand.com"
                      className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-white/30 focus:border-[#d4af37] focus:outline-none transition-colors"
                    />
                  </div>

                  <div>
                    <label className="block text-white/70 mb-1.5 font-medium">Project Scope</label>
                    <select
                      value={formData.projectType}
                      onChange={(e) => setFormData({ ...formData, projectType: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl bg-[#1a1a24] border border-white/10 text-white focus:border-[#d4af37] focus:outline-none transition-colors"
                    >
                      <option value="Ethnic Couture Showcase">Ethnic Couture Showcase (Reel + Stills)</option>
                      <option value="Lyrical & Dialogue Production">Lyrical & Dialogue Production</option>
                      <option value="Aesthetic UGC Product Feature">Aesthetic UGC Product Feature</option>
                      <option value="Brand Ambassador / Multi-Campaign">Brand Ambassador / Multi-Campaign</option>
                      <option value="Other Bespoke Collaboration">Other Bespoke Collaboration</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-white/70 mb-1.5 font-medium">Brief / Message *</label>
                  <textarea
                    required
                    rows={4}
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    placeholder="Describe your collection, preferred aesthetic direction, deadlines, and key requirements..."
                    className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-white/30 focus:border-[#d4af37] focus:outline-none transition-colors"
                  />
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    className="cursor-pointer w-full py-3.5 rounded-full bg-gradient-to-r from-[#d4af37] via-[#e5c07b] to-[#d4af37] text-[#0b0b0e] font-semibold uppercase tracking-wider text-xs sm:text-sm shadow-xl shadow-[#d4af37]/20 hover:scale-[1.01] active:scale-[0.98] transition-all flex items-center justify-center gap-2"
                  >
                    <span>Submit Collaboration Inquiry</span>
                    <Send className="w-4 h-4" />
                  </button>
                </div>

                <p className="text-[11px] text-white/40 text-center">
                  You can also directly reach out via Instagram Direct Message at <a href={CREATOR_DATA.socials.instagram} target="_blank" rel="noreferrer" className="text-[#e5c07b] underline">@nayrasheikh3552</a>
                </p>
              </form>
            </div>
          ) : (
            <div className="py-12 text-center flex flex-col items-center">
              <div className="w-16 h-16 rounded-full bg-[#143d34] border border-[#3dc789]/50 flex items-center justify-center text-[#3dc789] mb-4 shadow-xl">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h4 className="font-editorial text-3xl text-white font-normal">
                Inquiry Dispatched With Grace.
              </h4>
              <p className="mt-3 text-sm text-white/70 max-w-md font-sans-clean leading-relaxed">
                Thank you, <strong className="text-white">{formData.name}</strong>. Your proposal for <span className="text-[#e5c07b]">{formData.projectType}</span> has been logged. We will review your brief and connect shortly.
              </p>
              <button
                onClick={handleReset}
                className="cursor-pointer mt-8 px-8 py-3 rounded-full bg-white/10 hover:bg-white/15 text-white font-medium text-xs uppercase tracking-wider transition-colors"
              >
                Close Window
              </button>
            </div>
          )}
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
